

<footer>
		<div class="wrapp">
		<link href="https://fonts.googleapis.com/css?family=Days+One" rel="stylesheet">
		<center>
	<img src="img/footer.png" alt="210" width="210"/>
</center>
			<p align="justify">INSTITUTO TECNOLÓGICO SUPERIOR DE SAN ANDRÉS TUXTLA</p>
<p>CARRETERA COSTERA DEL GOLFO S/N, Km. 140 + 100 C.P. 95804 SAN ANDRÉS TUXTLA, VERACRUZ
		</div>
	</footer>