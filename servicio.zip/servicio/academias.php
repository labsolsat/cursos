<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Academias</title>
</head>
<body>
	<form action="registro_acad.php"  method="post"  >
	<fieldset  style="border:6px groove #ccc; background:#F8ECE0; margin:200px;
	padding: 10px; border-right:  ">
      <legend style="font-weight:bold; color:#61380B;">Academias</legend>
   <select name="academias">
   <option value="Lic.Administracion" required>Lic.Administracion</option> 
   <option value="Ing.Industrial" required>Ing.Industrial</option> 
   <option value="Ing.Electecánica " required>Ing.Electromecánica</option>
   <option value="Ing.Informatica" required>Ing.Informatica</option>
   <option value="Ing.Sistemas computacionales" required>Ing.Sistemas computacionales</option>
   <option value="Ing.Ambiental" required>Ing.Ambiental</option>
   <option value="Ing.Gestion Empresarial" required>Ing.Gestion Empresarial</option>
   <option value="Ing.Mecatrónica" required>Ing.Mecatrónica</option>
 </select>
      <br/>
      <br/>

<input type="date" required name="fecha">
      <input type="submit" value="Guardar" >
   </fieldset>

	</form>
</body>
</html>