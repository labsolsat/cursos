<?php
include("conex.php");
$id_curso=$_REQUEST['id_curso'];
$nom_curso=$_POST["nom_curso"];
$ini_curso=$_POST["ini_curso"];
$fin_curso=$_POST["fin_curso"];
$ciclo=$_POST["ciclo"];
$hrs_diarias=$_POST["hrs_diarias"];
$sql="UPDATE cursos SET nom_curso='$nom_curso',ini_curso='$ini_curso',fin_curso='$fin_curso',ciclo='$ciclo',hrs_diarias='$hrs_diarias' WHERE id_curso='$id_curso'";
// Actulizar datos del usuario

$res=mysqli_query($conexion,$sql);
echo "<br/>";
echo "Datos Actualizados Wiii \(^3^)/";

header("location:tabla.php");
//    *

?>