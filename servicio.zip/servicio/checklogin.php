<?php
session_start();
?>

<?php


include ('conex.php');



$username = $_POST['usuario'];
//	$username="guadalupe";
//$password="1234";

$password = $_POST['clave'];



$sql = "SELECT * FROM usuarios WHERE usuario = '$username' and pass = '$password'";

$result = $conexion->query($sql);
//echo "sql ",$result->password;

if($result->num_rows > 0){
}
	//$row = $result->fetch_array(MYSQLI_ASSOC);
	$row = $result->fetch_assoc();
	$passwd_hash = password_hash($row['pass'],PASSWORD_DEFAULT);
	
 if (password_verify($password,$passwd_hash)) { 
 	
    $_SESSION['loggedin'] = true;
    $_SESSION['username'] = $username;
    $_SESSION['start'] = time();
    $_SESSION['expire'] = $_SESSION['start'] + (5 * 60); ?>
    <h2><p> Bienvenido a Siescca  <?php  echo  $_SESSION['username']; ?>!</p></h2>
    <a href=panel-control.php>Panel de Control</a>
  <?php
 } else { 
   echo "Username o Password estan incorrectos.";

   echo "<br><a href='Login.php'>Volver a Intentarlo</a>";
 }

 mysqli_close($conexion); 
?>