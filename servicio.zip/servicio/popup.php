<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>Datos</title>
</head>
<body>
<!--<form action="destino.php" method="post">
Nombre <br>
<input type="text" name="nombre"> <br>
Apellidos<br>
<input type="text" name="apellidos"> <br>
<input type="submit" name="enviar" value="Enviar">
</form>-->
<div class="contenedor">
	<a href="#openmodal" class="open">Nuevo Curso</a>
	<section id="openmodal" class="modaldialog">
		<section class="modal">
			<a href="#close" class="close"> X  </a>
	<form action="guardar_curso.php" method="post" accept-charset="utf-8" class="form-curso" name="form1">
		<h2 class="form-titulo-curso"></h2>
		<div class="contenedor-inputs-curso">
<labe class="label-curso" >Nombre del curso</label>
<input type="text" placeholder="Curso " id="nom_curso" name="nom_curso" required class="input-60-curso"> 
<label class="label-curso">Inicio del curso</label>	
<input type="date" required name="ini_curso" required class="input-60-curso">
<labelclass="label-curso" >Fin del curso</label>	
<input type="date" required name="fin_curso" required class="input-60-curso">
<label class="label-curso">Ciclo escolar</label>
<input type="text" placeholder="Ciclo" id="ciclo" name="ciclo" required class="input-60-curso">
<labelclass="label-curso" >Horas diarias</label>
<input type="text" placeholder="Horas" id="hrs_diarias" name="hrs_diarias" required class="input-60-curso">  	
<input type="submit" value="Guardar" class="btn-guardar-curso">
		</div>
		<br>
	</form>
		</section>
	</section>
</div>




</body>
</html>