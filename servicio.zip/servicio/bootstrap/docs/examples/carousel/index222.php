<?php
header('Location:https://cursos.javanianos.com/moodle');
?>