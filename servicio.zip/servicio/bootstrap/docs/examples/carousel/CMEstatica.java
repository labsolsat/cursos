
class CMEstatica{
	public static void main(String []agrs){
		int v[];
		Scanner sc = new Scannner(System.in);
sysrem.out.print("Ing tam array...");
int tam = 

	}



}