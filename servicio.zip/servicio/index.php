<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/estilofoo.css">
	<title>Sistema psicopedagógico</title>
</head>
<body>
	<header>
		<nav class="navbar navbar-inverse navbar-static-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navegacion-sp">
						<span class="sr-only">Desplegar / Ocultar Menu</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<img style="float:left;" src="img/logo1.png" alt="60" width="60"/>

				<a href="index.php" class="navbar-brand tam">Sistema Psicopedagógico </a>
			</div>
			<!--Inicia Menu-->
			<div class="collapse navbar-collapse" id="navegacion-sp">
				<ul class="nav navbar-nav">
					<li class=" active"><a href="index.php">Inicio</a></li>
					<li class="dropdown">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
								Consultas <span class="caret"></span>
							</a>

							<?php 
                     require('menu.php');
							 ?>
							
						</li>
					<li><a href="quienson.php">Quienes Somos</a></li>
				</ul>
				<!--barra de busqueda-->
			</div>
		 </div>	
		</nav>
	</header>
	<!-- Aqui va el jumbotron -->
	<section class="jumbotron">
		<div class="container">
			<h1></h1>
		</div>
	</section>
	<section class="main">
		<div class="wrapp">
			<div class="mensaje">
				<h2>Bienvenido!</h2>
			</div>
 
			<div class="articulo">
				<article>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

                    

					</p>
					<br/>
					<br/>
					
				</article>
			</div>
 
		</div>
	</section>
	
	<!--inicia formulario de inicio de sesion-->
	
	<form action="checklogin.php" method="post" accept-charset="utf-8" class="form-sesion">
		<h2 class="form-titulo">Inicio de Sesion</h2>
		<div class="contenedor-inputs">
<input type="text" placeholder="&#128273; Usuario " id="usuario" name="usuario" required class="input-70"> 
<input type="password" placeholder="&#128274; Password" id="clave" name="clave" required class="input-70"> 	
<input type="submit" value="Ingresar" class="btn-iniciar">
		</div>
		<br>
	</form>
	
	
	<br>
	<br>
	<br>
		<?php
include ('footer.php');
	?>
	

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>