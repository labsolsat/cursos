<?php
include("conex.php");

$id_curso=$_REQUEST['id_curso'];
$sql="DELETE FROM cursos  WHERE id_curso='$id_curso'";
// Eliminar  datos del usuario
$res=mysqli_query($conexion,$sql);
echo "<br/>";
echo "Datos Eliminados Wiii \(^3^)/";
header("location:tabla.php");
//   *

?>
