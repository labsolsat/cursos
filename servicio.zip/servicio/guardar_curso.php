<?php
include("conex.php");
$nom_curso=$_POST["nom_curso"];
$ini_curso=$_POST["ini_curso"];
$fin_curso=$_POST["fin_curso"];
$ciclo=$_POST["ciclo"];
$hrs_diarias=$_POST["hrs_diarias"];
$sql=("INSERT INTO cursos (nom_curso,ini_curso,fin_curso,ciclo,hrs_diarias) VALUES ('$nom_curso','$ini_curso','$fin_curso','$ciclo','$hrs_diarias')");
$res=mysqli_query($conexion,$sql);

if (mysqli_errno($conexion)==0){
echo "<br/>";
header('Location: tabla.php');
}else{
if (mysqli_errno($conexion)==1062){
echo "<h2>CLAVE DUPLICADA, no se ha podido insertar<h2>";
echo "<a href='cursos.php'>Volver</a>";
} else {
	$numeroERROR=mysqli_errno($conexion);
	$descripcionERROR=mysqli_errno($conexion);
	echo "<h2>Nº de error: $numeroERROR * Descripción: $descripcionERROR<h2>";
	}
}
mysqli_close($conexion);

?>