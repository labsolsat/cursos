<ul class="dropdown-menu" role="menu">
								<li><a href="#">Opciones</a></li>
								<li class="divider"></li>
								<li><a href="academias.php">Academias</a></li>
								<li><a href="cursos.php">Cursos</a></li>
								<li><a href="#">Categoria #4</a></li>
							</ul>