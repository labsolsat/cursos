<?php 
$nom=$_POST['academias'];
echo "Usted Elijio "." ".$nom;
$fech=$_POST['fecha'];
echo "Y la fecha que elijio es" .$fech;

 ?>