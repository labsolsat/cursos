<html lang="es">
<head>
	<title>Actualizar</title>
	<link rel="stylesheet" type="text/css" href="css/estilos.css"/>
</head>
<body>
<center>
<?php
	
	$id_curso=$_REQUEST['id_curso'];

            include("conex.php");
            $query_mostrar="SELECT * FROM cursos WHERE id_curso='$id_curso' ";
            $mostrar=mysqli_query($conexion,$query_mostrar);
            $row=$mostrar->fetch_assoc();
                ?>
<form action="modificar_proceso.php?id_curso=<?php echo $row['id_curso'];?>" method="POST" class="form-curso">	
<h2 class="form-titulo-curso"></h2>
		<div class="contenedor-inputs-curso">
<label class="label-curso">Nombre del curso</label>
<input type="text" placeholder="Curso " id="nom_curso" name="nom_curso" required class="input-60-curso" value="<?php echo $row['nom_curso'];?>"> 
<label class="label-curso">Inicio del curso</label>	

<input type="date" required name="ini_curso" required class="input-60-curso" value="<?php echo $row['ini_curso'];?>">

<label class="label-curso">Fin del curso</label>	
<input type="date" required name="fin_curso" required class="input-60-curso" value="<?php echo $row['fin_curso'];?>">

<label class="label-curso">Ciclo escolar</label>
<input type="text" placeholder="Ciclo" id="ciclo" name="ciclo" required class="input-60-curso" value="<?php echo $row['ciclo'];?>">

<label class="label-curso" >Horas diarias</label>
<input type="text" placeholder="Horas" id="hrs_diarias" name="hrs_diarias" required class="input-60-curso" value="<?php echo $row['hrs_diarias'];?>"> 

<input type="submit" value="Guardar" class="btn-guardar-curso">
		</div>
		<br>


</form >






</center>
</body>
</html>
