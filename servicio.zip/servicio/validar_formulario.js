function validar () {
	// Nombre...
	if (document.form1.nom_curso.value.length==0) {
     alert("campo vacio ");
     document.form1.nom_curso.focus();
     return 0;
	}else{
   alert("Datos correctos");
	}

}