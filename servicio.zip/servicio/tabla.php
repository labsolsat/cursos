<html lang="es">
<head>
<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/estilofoo.css">
	<title>Sistema psicopedagógico</title>
</head>
<body>
<header>
		<nav class="navbar navbar-inverse navbar-static-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navegacion-sp">
						<span class="sr-only">Desplegar / Ocultar Menu</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<img style="float:left;" src="img/logo1.png" alt="60" width="60"/>

				<a href="index.php" class="navbar-brand tam">Sistema Psicopedagógico </a>
			</div>
			<!--Inicia Menu-->
			<div class="collapse navbar-collapse" id="navegacion-sp">
				<ul class="nav navbar-nav">
					<li class=" active"><a href="index.php">Inicio</a></li>
					<li class="dropdown">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button">
								Consultas <span class="caret"></span>
							</a>
							<?php 
                     require('menu.php');
							 ?>
							
						</li>
					<li><a href="quienson.php">Quienes Somos</a></li>
				</ul>
				<!--barra de busqueda-->
			</div>
		 </div>	
		</nav>
	</header>
	<!-- Aqui va el jumbotron -->
	<section class="jumbotron">
		<div class="container">
			<h1></h1>
		</div>
	</section>
	<section class="main">
		<div class="wrapp">
			<div class="mensaje">
			<center>
			<h2>Cursos impartidos</h2>
			</center>
				
			</div>
 
			<div class="articulo">
				<article>
					
					
				</article>
			</div>
 
		</div>
	</section>
<center>
<form action="cursos.php" method="post">
<div class="table-responsive">
  <table border="3" class="table table-bordered table-hover">
	    <thead>
	    	<tr class="success">
	    	<!--<th colspan="1"><a href="formulario.php">Nuevo</a></th>-->
	        <th colspan="9">
	        <center>
	        <p></p>
	        </center>
	       
	        </th>
	    	</tr>
	    </thead>
	    <tbody>
	    	<tr>
	    	<br>
	    	<br>
	    	<br>
	    		<td class="active">ID</td>
	    		<td class="success">Nombre del curso</td>
	    		<td class="success">Inicio del curso</td>
	    		<td class="success">Fin del curso</td>
	    		<td class="success">Ciclo</td>
	    		<td class="success">Horas diarias</td>
	    		<td class="danger" colspan="2">Operaciones</td>
	    	</tr>
	    	<?php
            include("conex.php");
            $query_mostrar="SELECT * FROM cursos";
            $mostrar=mysqli_query($conexion,$query_mostrar);
            while ($row=$mostrar->fetch_assoc()) {
            	
                ?>
                <tr>
                	<td class="active"><?php echo $row['id_curso'];?></td>
                	<td class="info"><?php echo $row['nom_curso'];?></td>
                	<td class="info"><?php echo $row['ini_curso'];?></td>
                	<td class="info"><?php echo $row['fin_curso'];?></td>
                	<td class="info"><?php echo $row['ciclo'];?></td>
                	<td class="info"><?php echo $row['hrs_diarias'];?></td>
                	<td class="warning"><a href="modificar.php?id_curso=<?php echo $row['id_curso'];?>">Modificar</a></td>
                	<td class="danger"><a href="eliminar.php?id_curso=<?php echo $row ['id_curso'];?>">Eliminar</a></td>
                	
                </tr>
             <?php
                 }

	    	?>

	    </tbody>

	</table>
</div>
	
	<br>
	<br>
	<input type="submit" value="Nuevo"/>
	<br>
	<br>
</form>	
</center>
<br>
<br>
<?php
include ('footer.php');
	?>
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>