<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet"  href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilofoo.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>Sistema psicopedagógico</title>
</head>
<body>
	<header>
		<nav class="navbar navbar-inverse navbar-static-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navegacion-sp">
						<span class="sr-only">Desplegar / Ocultar Menu</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<img style="float:left;" src="img/logo1.png" alt="60" width="60"/>

				<a href="index.php" class="navbar-brand tam">Sistema Psicopedagógico </a>
			</div>
			<!--Inicia Menu-->
			<div class="collapse navbar-collapse" id="navegacion-sp">
				<ul class="nav navbar-nav">
					<li class=" active"><a href="index.php">Inicio</a></li>
					<li class="dropdown">
							<a href="" class="dropdown-toggle" data-toggle="dropdown" role="button">
								Consultas <span class="caret"></span>
							</a>
							<?php 

                     require('menu.php');
							 ?>
						</li>
					<li><a href="quienson.php">Quienes Somos</a></li>
				</ul>
				<!--barra de busqueda-->
			</div>
		 </div>	
		</nav>
	</header>
	<!-- Aqui va el jumbotron -->
	<section class="jumbotron">
		<div class="container">
			<h1></h1>
		</div>
	</section>
	<section class="main">
		<div class="wrapp">
			<div class="mensaje">
			<center>
				<h2>Cursos</h2>
			</center>
				
			</div>
 
			<div class="articulo">
				<article>
					
				</article>
			</div>
 
			
		</div>
	</section>
	<!--Formulario-->
<form action="guardar_curso.php" method="post" accept-charset="utf-8" class="form-curso" name="form1">
		<h2 class="form-titulo-curso"></h2>
		<div class="contenedor-inputs-curso">
<label class="label-curso">Nombre del curso</label>
<input type="text" placeholder="Curso " id="nom_curso" name="nom_curso" required class="input-60-curso"> 
<label class="label-curso">Inicio del curso</label>	
<input type="date" required name="ini_curso" required class="input-60-curso">
<label class="label-curso">Fin del curso</label>	
<input type="date" required name="fin_curso" required class="input-60-curso">
<label class="label-curso">Ciclo escolar</label>
<input type="text" placeholder="Ciclo" id="ciclo" name="ciclo" required class="input-60-curso">
<label class="label-curso" >Horas diarias</label>
<input type="text" placeholder="Horas" id="hrs_diarias" name="hrs_diarias" required class="input-60-curso">  	
<input type="submit" value="Guardar" class="btn-guardar-curso">
		</div>
		<br>
	</form>

	<br>
	<br>
	<br>
		<?php 
include ('footer.php');
	?>
	

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>